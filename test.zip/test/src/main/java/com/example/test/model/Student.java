package com.example.test.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

public class Student {

    private long rowId;
    private UUID studentId;
    private String studentName;

    public Student(long rowId, String studentName, UUID studentId) {
        this.rowId = rowId;
        this.studentId = studentId;
        this.studentName = studentName;
    }

    public Student(){};

    public Student(@JsonProperty("id")long rowId,
                   @JsonProperty("name")String studentName) {
        this.studentId = studentId;
        this.studentName = studentName;
    }

    public long getStudentId() {
        return rowId;
    }

    public String getStudentName() {
        return studentName;
    }

    @Override
    public String toString() {
        return studentId+", " + studentName;
    }

    public void setRowId(long rowId) {
        this.rowId = rowId;
    }

    public void setStudentId(UUID studentId) {
        this.studentId = studentId;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
}
