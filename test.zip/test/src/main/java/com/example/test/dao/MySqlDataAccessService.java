package com.example.test.dao;

import com.example.test.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository("mysql")
public class MySqlDataAccessService implements StudentDao{


    @Autowired
    JdbcTemplate jdbcTemplate;


    @Override
    public int insertStudent(UUID id, Student student) {
        return 0;
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        students.addAll(
                jdbcTemplate.query("Select * from Student;",
                        new BeanPropertyRowMapper<>(Student.class)));
        return students;
    }

    @Override
    public int deleteStudentById(UUID id) {
        return 0;
    }

    @Override
    public int updateStudentById(UUID id, Student student) {
        return 0;
    }

    @Override
    public Optional<Student> selectStudentById(UUID id) {
        return Optional.empty();
    }
}
